package users;

/**
 * 
 * @author Afonso Batista 57796
 * @author Joao Jorge 57994
 */
public class ClerkClass extends UserClass {

	public ClerkClass(String id, String level) {
		super(id, level, CLERK);
		
	}
}
